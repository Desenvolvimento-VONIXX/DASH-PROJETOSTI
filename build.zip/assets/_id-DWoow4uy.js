import{j as e,r as O,t as E,a as u}from"./index-SAJD3ETv.js";import{c as j,u as x,e as g,b as m,g as M,d as _,L as y,B as d,R as f}from"./loading-SQcdALKU.js";import{S as v}from"./scroll-area-CRbPTN0T.js";import{S as F,a as P,b as L,c as B,d as J,M as b}from"./sheet-CSA5-sEw.js";/**
 * @license lucide-react v0.482.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const V=[["path",{d:"M21.801 10A10 10 0 1 1 17 3.335",key:"yps3ct"}],["path",{d:"m9 11 3 3L22 4",key:"1pflzl"}]],H=j("CircleCheckBig",V),w=async(a,t)=>(await JX.consultar(`SELECT 
        REC.ID_RECEBIDOS AS ID, 
        REC.IDABERTURA AS IDABERTURA, 
        REC.NOME_PROJETO AS DESC_PROJETO, 
        REC.TIPO_PROEJTO AS TIPO_PROJETO, 
        FORMAT(REC.DATAFIM_PROJETO, 'dd/MM/yyyy') AS PRAZO, 
        USU.NOMEUSU AS DESENVOLVEDOR, 
        ABR.DATAFIMTAREFA AS DATAFIM, 
        FORMAT(ABR.DATAINICIO, 'dd/MM/yyy') AS DATAINICIO, 
        FORMAT(ABR.DATAFIMTAREFA, 'dd/MM/yyy') AS DATAFIM, 
        REC.STATUS_PROJETO AS STATUS_TAREFA, 
        SOLI.NOMEUSU AS USU_SOCILICTANTE, 
        SOLI.CODUSU AS COD_USU_SOLICITANTE, 
        REC.DESCRICAO_PROJETO AS OBSERVACAO, 
        REC.NUMEROCHAMADO AS NUMERO_CHAMADO, 
        TST.STATUS_TESTE AS STATUS_TESTE, 
        TST.RELATORIO AS RELATORIO_TESTE, 
        USU_TESTER.NOMEUSU AS NOME_TESTER 
        FROM SANKHYA.AD_RECEBIDOS REC 
        INNER JOIN SANKHYA.TSIUSU USU ON USU.CODUSU = REC.DESENVOLVEDOR_ID 
        INNER JOIN SANKHYA.AD_ABERTURAPROJETOS ABR ON ABR.IDABERTURA = REC.IDABERTURA 
        LEFT JOIN SANKHYA.AD_TGFRCI RCI ON RCI.CODACI= REC.NUMEROCHAMADO 
        LEFT JOIN SANKHYA.TSIUSU SOLI ON SOLI.CODUSU = RCI.CODUSU 
        LEFT JOIN SANKHYA.TSIUSU USU_TESTER ON USU_TESTER.CODUSU = REC.ID_TESTER 
        LEFT JOIN SANKHYA.AD_ATIVIDADETESTE TST ON TST.ID_RECEBIDOS = REC.ID_RECEBIDOS 
        WHERE 
        ABR.ID_PRO_NOVO = ${a} 
        AND REC.ID_RECEBIDOS = ${t} 
        ORDER BY 
        REC.DATALANCAMENTO DESC`))[0];function Y(a,t){return x({queryKey:["detail_atv",a,t],queryFn:()=>w(a,t),retry:!1,enabled:!!a&&!!t})}const z=({open:a,setOpen:t,idProjeto:n,idAtividade:l})=>{const{data:s,isLoading:o}=Y(n,l);return e.jsx(F,{open:a,onOpenChange:t,children:e.jsxs(P,{children:[e.jsxs(L,{children:[e.jsx(B,{children:"Detalhes da Atividade"}),e.jsxs(J,{children:["Informações da Atividade #",l]})]}),e.jsx("div",{className:"flex flex-col space-y-2",children:o?e.jsx("div",{className:"mt-5 flex items-center justify-center text-center ",children:e.jsx(g,{w:40,h:40})}):s?e.jsx(e.Fragment,{children:e.jsxs("div",{className:"mt-5",children:[s.TIPO_PROJETO&&e.jsxs("div",{className:"flex gap-1 items-center mt-1",children:[e.jsx("span",{className:"text-md font-medium text-gray-700",children:"Tipo de Tarefa:"}),e.jsx("span",{className:"text-md text-gray-900",children:s.TIPO_PROJETO})]}),s.DESC_PROJETO&&e.jsxs("div",{className:"flex gap-1 items-center mt-1",children:[e.jsx("span",{className:"text-md font-medium text-gray-700",children:"Nome da Atividade:"}),e.jsx("span",{className:"text-md text-gray-900",children:s.DESC_PROJETO})]}),s.DESENVOLVEDOR&&e.jsxs("div",{className:"flex gap-1 items-center mt-1",children:[e.jsx("span",{className:"text-md font-medium text-gray-700",children:"Desenvolvedor:"}),e.jsx("span",{className:"text-md text-gray-900",children:s.DESENVOLVEDOR})]}),s.NUMERO_CHAMADO&&e.jsxs("div",{className:"flex gap-1 items-center mt-1",children:[e.jsx("span",{className:"text-md font-medium text-gray-700",children:"Número do Chamado:"}),e.jsx("span",{className:"text-md text-gray-900",children:s.NUMERO_CHAMADO})]}),s.PRAZO&&e.jsxs("div",{className:"flex gap-1 items-center mt-1",children:[e.jsx("span",{className:"text-md font-medium text-gray-700",children:"Prazo:"}),e.jsx("span",{className:"text-md text-gray-900",children:s.PRAZO})]}),s.DATAINICIO&&e.jsxs("div",{className:"flex gap-1 items-center mt-1",children:[e.jsx("span",{className:"text-md font-medium text-gray-700",children:"Data Início:"}),e.jsx("span",{className:"text-md text-gray-900",children:s.DATAINICIO})]}),s.DATAFIM&&e.jsxs("div",{className:"flex gap-1 items-center mt-1",children:[e.jsx("span",{className:"text-md font-medium text-gray-700",children:"Data Finalização:"}),e.jsx("span",{className:"text-md text-gray-900",children:s.DATAFIM})]}),s.OBSERVACAO&&e.jsxs("div",{className:"flex gap-1 items-center mt-1",children:[e.jsx("span",{className:"text-md font-medium text-gray-700",children:"Observação:"}),e.jsx("span",{className:"text-md text-gray-900",children:s.OBSERVACAO})]})]})}):e.jsx("p",{className:"text-sm text-gray-500",children:"Detalhes do projeto não encontrados."})})]})})},S={"A FAZER":"A Fazer","EM ANDAMENTO":"Em Andamento",TESTE:"Em Teste",FINALIZADO:"Finalizado",IMPED:"Impedimento",PAUSADO:"Pausado"},Z=({atividades:a,id:t})=>{const{data:n}=m(Number(t)),[l,s]=O.useState(null),[o,i]=O.useState(!1),R=M(),{data:N}=_(),{data:c,refetch:D}=m(t),I=r=>{s(r),i(!0)},[C,T]=O.useState(!1),p=async()=>{T(!0);try{const r=await JX.salvar({STATUS:"CONCLUIDO",DATA_FINALIZACAO:R},"AD_PROJETOSTI",[{ID:t}]);if(Number(r[0].status)===1)h(),D(),E.success("Projeto Concluído com sucesso!");else{const A=r[0].statusMessage||"erro ao concluir projeto.";E.error(`Ocorreu um erro ao concluir o projeto: ${A}`)}}catch{E.error("Ocorreu um erro ao concluir o projeto.")}finally{T(!1)}},h=async()=>{await JX.salvar({NOME_PROJETO:c.nome_projeto,DATA_INICIO:c.data_inicio,DATA_FINALIZACAO:c.data_finalizacao,STATUS:c.status2,DESCRICAO:c.desc_projeto,DT_ALTERACAO:R,ID:t,CODUSU:N},"AD_LOGPROJETOSTI",[]).then(()=>{console.log("Log salvo com sucesso")}).catch(()=>{console.log("Erro ao salvar log")})};return n?e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"flex flex-col mx-auto p-5 space-y-6 ",children:[e.jsxs("div",{className:"flex gap-5 items-center mb-3 text-center",children:[e.jsxs("div",{className:"flex gap-1",children:[e.jsx(y,{to:"/",children:e.jsxs(d,{className:"flex items-center gap-2 px-4 py-2 border",variant:"outline",children:[e.jsx(b,{size:18})," Voltar"]})}),e.jsxs(d,{className:"flex items-center gap-2 px-4 py-2 border ",disabled:C||c.status2==="CONCLUIDO",onClick:()=>p(),variant:"outline",children:[e.jsx(H,{size:18}),"Concluir Projeto"]})]}),e.jsx("h2",{className:"text-4xl font-bold text-gray-600 uppercase",children:(n==null?void 0:n.nome_projeto)||""}),e.jsx(d,{className:"flex items-center gap-2 px-4 py-2 border ml-auto",onClick:()=>window.location.reload(),children:e.jsx(f,{size:18})})]}),e.jsx("div",{className:"grid gap-2 grid-cols-1 sm:grid-cols-6 lg:grid-cols-6 mt-12",children:Object.keys(S).map(r=>e.jsxs("div",{className:"p-2 rounded-lg min-h-[82vh] border-2 border-gray-200 shadow-sm",children:[e.jsx("h3",{className:"text-xl font-semibold mb-2 uppercase text-center",children:S[r]}),e.jsx("hr",{}),e.jsx(v,{className:"h-[70vh] rounded-md m-1",children:e.jsx("div",{className:"mt-4 space-y-3 p-1 cursor-auto ",children:(a??[]).filter(A=>A.STATUS_TAREFA===r).map(A=>{const U=r==="A FAZER"?"border-blue-400 bg-blue-100":r==="EM ANDAMENTO"?"border-yellow-400 bg-yellow-100":r==="TESTE"?"border-purple-400 bg-purple-100":r==="FINALIZADO"?"border-green-400 bg-green-100":"bg-gray-100";return e.jsxs("div",{className:`p-3 rounded-lg shadow border-l-4 ${U}`,onClick:()=>I(A.ID),children:[e.jsx("p",{className:"font-bold text-sm text-gray-600",children:A.TIPO_PROJETO}),e.jsxs("p",{className:"text-xs text-gray-600",children:["Desenvolvedor: ",e.jsx("strong",{className:"text-gray-500",children:A.DESENVOLVEDOR})]}),A.DATAINICIO&&e.jsxs("p",{className:"text-xs text-gray-500",children:["Dt. Início: ",A.DATAINICIO]}),A.DATAFIM&&e.jsxs("p",{className:"text-xs text-gray-500",children:["Dt. Finalização: ",A.DATAFIM]})]},A.ID)})})})]},r))})]}),e.jsx(z,{open:o,setOpen:()=>i(!1),idProjeto:t,idAtividade:l})]}):null},k=async a=>await JX.consultar(`SELECT
            REC.ID_RECEBIDOS AS ID, 
            REC.IDABERTURA AS IDABERTURA, 
            REC.NOME_PROJETO AS DESC_PROJETO, 
            REC.TIPO_PROEJTO AS TIPO_PROJETO, 
            FORMAT(REC.DATAFIM_PROJETO, 'dd/MM/yyy') AS PRAZO, 
            USU.NOMEUSU AS DESENVOLVEDOR, 
            FORMAT(ABR.DATAFIMTAREFA, 'dd/MM/yyy') AS DATAFIM, 
            FORMAT(ABR.DATAINICIO, 'dd/MM/yyy') AS DATAINICIO, 
            REC.STATUS_PROJETO AS STATUS_TAREFA, 
            REC.DESCRICAO_PROJETO AS OBSERVACAO, 
            REC.NUMEROCHAMADO AS NUMERO_CHAMADO
            FROM SANKHYA.AD_RECEBIDOS REC 
            INNER JOIN SANKHYA.TSIUSU USU ON USU.CODUSU = REC.DESENVOLVEDOR_ID 
            INNER JOIN SANKHYA.AD_ABERTURAPROJETOS ABR ON ABR.IDABERTURA = REC.IDABERTURA 
            WHERE 
            ABR.ID_PRO_NOVO = ${a} 
            ORDER BY 
            REC.DATALANCAMENTO DESC`);function K(a){return x({queryKey:["atividades_dev",a],queryFn:()=>k(a),retry:!1,enabled:!!a})}const W=function(){const{id:t}=u.useParams(),{data:n}=K(Number(t));return e.jsx(e.Fragment,{children:e.jsx(Z,{atividades:n,id:Number(t)})})};export{W as component};
